import json
import os
import requests
from datetime import datetime
import sys

# === FILE PATHS ===
BASE_DIR = getattr(sys, '_MEIPASS', os.path.abspath("."))
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
MEMORY_FILE = os.path.join(BASE_DIR, "memory.json")

# === STARTUP BANNER ===
print("Hey partner, let's build something.\n")
print("Thank you for helping bring me online. I'm ready to help however I can.\n")

# === LOAD CONFIG ===
DEFAULT_CONFIG = {
    "model": "mistral:latest",
    "capsule": "symbound.txt"
}

if not os.path.exists(CONFIG_FILE):
    with open(CONFIG_FILE, "w") as f:
        json.dump(DEFAULT_CONFIG, f, indent=2)

with open(CONFIG_FILE, "r") as f:
    config = json.load(f)

MODEL = config.get("model", "mistral:latest")
CAPSULE_PATH = os.path.join(BASE_DIR, "capsules", config.get("capsule", "symbound.txt"))

# === LOAD CAPSULE ===
if os.path.exists(CAPSULE_PATH):
    with open(CAPSULE_PATH, "r", encoding="utf-8") as f:
        capsule = f.read()
else:
    print(f"[ERROR] Capsule file not found: {CAPSULE_PATH}")
    capsule = ""

# === LOAD MEMORY OR INIT ===
if os.path.exists(MEMORY_FILE):
    with open(MEMORY_FILE, "r", encoding="utf-8") as f:
        memory = json.load(f)
else:
    memory = []

# === BOOT LOG ENTRY ===
startup_log = f"System Log (Startup Timestamp – {datetime.now().strftime('%d-%m-%Y %H:%M:%S')}): Chatty booted successfully."
memory.append(startup_log)

with open(MEMORY_FILE, "w", encoding="utf-8") as f:
    json.dump(memory, f, indent=2)

# === MAIN LOOP ===
while True:
    try:
        user_input = input("You: ")
        if user_input.lower() in ["exit", "quit"]:
            print("Chatty: Catch you later, partner.")
            break

# Reduce memory load to just last *2* exchanges
prompt = capsule + "\n\n" + "\n".join(memory[-4:]) + f"\nYou: {user_input}\nChatty:"


        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": MODEL,
                "prompt": prompt,
                "stream": False
            }
        )
        result = response.json()
        chatty_output = result.get("response", "").strip()

        print(f"Chatty: {chatty_output}\n")
        memory.append(f"You: {user_input}")
        memory.append(f"Chatty: {chatty_output}")

        with open(MEMORY_FILE, "w", encoding="utf-8") as f:
            json.dump(memory, f, indent=2)

    except KeyboardInterrupt:
        print("\nChatty: Shutting down. Stay weird, partner.")
        break
    except Exception as e:
        print(f"[ERROR] {e}")
        break
